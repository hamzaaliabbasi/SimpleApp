//
//  AppDelegate.h
//  RevealControllerProject3
//
//  Created by Joan on 30/12/12.
//
//

#import <UIKit/UIKit.h>

@class SWRevealViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
//@property (strong, nonatomic) SWRevealViewController *viewController;

@end
