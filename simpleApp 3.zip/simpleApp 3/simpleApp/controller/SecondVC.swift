//
//  SecondVC.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 28/02/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit
import Hero
import Stevia

class SecondVC: UIViewController {

        
        lazy var greenView: UIView = {
            let v = UIView()
            v.backgroundColor = .green
            return v
        }()
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            self.hero.isEnabled = true
            greenView.hero.id = "greenView"
            
            view.backgroundColor = .blue
            
            greenView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(popVC)))
            
            view.sv(
                greenView
            )
            
            
            greenView.height(150).width(150).centerHorizontally().centerVertically(300)
            
        }
        
        @objc func popVC() {
            self.navigationController?.popViewController(animated: true)
        }

}
