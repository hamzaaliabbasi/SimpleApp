//
//  mainpageViewController.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 21/02/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit
import SWRevealViewController
 
class mainpageViewController: BaseActivityViewController,UITableViewDelegate,UITableViewDataSource{
    
    
    override func viewDidLoad() {
        //         delegate?.tranferData(data: arr)
        
        
        
        if self.revealViewController() != nil {
            main.target = self.revealViewController()
            main.action = #selector(SWRevealViewController.revealToggle(_:))
            self.navigationItem.title = "Main"
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            self.table.tableFooterView = UIView()
            
        }
        
        
        
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        
    }
    //Mark: -global variables
    let menu = ["Buy Insurance","Location","Policy Management","Car Maintenance Schedule","Payment","SOS Numbers","Contact us"]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menu.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        

     let cell = table.dequeueReusableCell(withIdentifier: "cellpreviewTableViewCell") as! cellpreviewTableViewCell
       cell.logo.image = UIImage(named: menu[indexPath.row])
        cell.label.text = menu[indexPath.row]
   return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }

    
    @IBAction func policy(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CardMain") as! CardMain
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0{
            let vc = UIStoryboard.init(name: "SecondMenu", bundle: nil).instantiateViewController(withIdentifier: "CameraViewController") as! CameraViewController
//
            self.present(vc, animated: false, completion: nil)
         
            
        }
        if indexPath.row == 1
        {
            let vc = UIStoryboard.init(name: "MapStoryboard", bundle: nil).instantiateViewController(withIdentifier: "MapViewController") as! MapViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
        if indexPath.row == 2
        {
            let vc = UIStoryboard.init(name: "SecondMenu", bundle: nil).instantiateViewController(withIdentifier: "policyManagement") as! policyManagement
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
        if indexPath.row == 3
        {
            let vc = UIStoryboard.init(name: "SecondMenu", bundle: nil).instantiateViewController(withIdentifier: "CollectionViewController") as! CollectionViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
        
        if indexPath.row == 4{
            let vc = UIStoryboard.init(name: "SecondMenu", bundle: nil).instantiateViewController(withIdentifier: "policy") as! PaymentScreenVC
            self.navigationController?.pushViewController(vc, animated: true)

        }
        
        }

   
    
    @IBOutlet weak var main: UIBarButtonItem!
    
    @IBAction func itemButton(_ sender: Any) {
        

    }
    
    
    
    @IBOutlet weak var table: UITableView!
    

    

}
