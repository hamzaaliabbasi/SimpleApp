//
//  dataparse.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 22/02/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import Foundation
protocol dataparsing {
    func tranferData(data: [String])
}
