//
//  Login.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 25/02/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit
import SWRevealViewController
import FBSDKCoreKit
import FBSDKLoginKit
import AudioToolbox


class Login:BaseActivityViewController,FBSDKLoginButtonDelegate {
    func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error!) {
        if error != nil{
              let Alert = UIAlertController(title: "Error", message: "Some error occured in login", preferredStyle: .alert)
        Alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(Alert, animated: true, completion: nil)
        }
        else if result.isCancelled{
            let Alert = UIAlertController(title: "Cancelled", message: "Login Cancelled", preferredStyle: .alert)
            Alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
              self.present(Alert, animated: true, completion: nil)
        }
        else{
            let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "swreveal") as! SWRevealViewController
            let Alert = UIAlertController(title: "Login Successful", message: "Press OK to continue..", preferredStyle: .alert)
            
            Alert.addAction(UIAlertAction(title: "OK", style: .default, handler: {(alert: UIAlertAction!) in
                 self.present(Alert, animated: true, completion: nil)}))
            
        }
        
        }
        
    
    
    
    func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!) {
        
        
        
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Login") as? Login
       let Alert = UIAlertController(title: "Logout", message: "You Logged out your Facebook account", preferredStyle: .alert)
        Alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(Alert, animated: true, completion: nil)
        
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        

        // Do any additional setup after loading the view.
       // self.navigationItem.title = "Login"
        signup.isUserInteractionEnabled = true
        let tapAction = UITapGestureRecognizer(target: self, action: #selector(self.actionTapped(_:)))
            tapAction.numberOfTapsRequired = 1
        signup.addGestureRecognizer(tapAction)
     fb.readPermissions = ["public_profile","email"]
      
//     fb.setBackgroundImage(UIImage(named: "facebook"), for: .normal)
//      fb.setTitleColor(UIColor.blue, for: .normal)
        fb.delegate = self
    
      
        
        
        
        
    }
    
    @IBOutlet weak var signup: UILabel!
    
    @IBOutlet weak var fb: FBSDKLoginButton!
    
    @IBOutlet weak var number: UITextField!
    
    @IBOutlet weak var password: UITextField!
    @IBAction func submit(_ sender: Any) {
         AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
        
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "swreveal") as? SWRevealViewController
        self.performSegue(withIdentifier: "go", sender: self)
    }
    
    @IBAction func facebook(_ sender: Any) {
    }
    @IBAction func google(_ sender: Any) {
    }
    @objc func actionTapped(_ sender: UITapGestureRecognizer) {
         //let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "signup") as? Signup
        self.performSegue(withIdentifier: "signup", sender: self)
        
    }
    
}
