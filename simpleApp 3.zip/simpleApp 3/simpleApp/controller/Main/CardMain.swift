//
//  CardMain.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 01/03/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class CardMain: UIViewController,UITableViewDataSource,UITableViewDelegate//,UIViewControllerAnimatedTransitioning,UIPercentDrivenInteractiveTransition {
{
//func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
//      return  0.5
//    }
//    
//    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
//        self
//    }
//    func interactionControllerForPresentation(using animator: UIViewControllerAnimatedTransitioning) -> UIViewControllerInteractiveTransitioning? {
//        // Presenting usually doesn't have any interactivity
//        return nil
//    }
//    func interactionControllerForDismissal(using animator: UIViewControllerAnimatedTransitioning) -> UIViewControllerInteractiveTransitioning? {
//        return self
//    }
    
     lazy var arr = ["Family Insurance","Car Insurance","Home Insurance","Health Insurance","Educational Insurance","Business Insurance"]
    let desc = ["You can never be too sure about what lies ahead, especially when it comes to your health or to the...","Vehicle insurance is insurance for cars, trucks, motorcycles, and other road vehicles...","This policy has been specifically designed with the intention to provide the maximum risk coverage for Home...","Health insurance is an insurance that covers the whole or a part of the risk of a person incurring...","Child Education is a plan for the protection of child's future. It provides a lump sum benefit for the child at ...","Business insurance coverage protects businesses from losses due to events that may occur during the normal..."]
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = table.dequeueReusableCell(withIdentifier: "CardViewClass") as! CardViewClass
        cell.no.text =  arr[indexPath.row]
    cell.policy.text = desc[indexPath.row]
        cell.policyimage.image = UIImage(named: arr[indexPath.row])
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 300
    }
    @IBOutlet weak var table: UITableView!
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        // Do any additional setup after loading the view.
//    }
//

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
