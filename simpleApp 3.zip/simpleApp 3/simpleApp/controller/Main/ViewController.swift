//
//  ViewController.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 21/02/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit


class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate{
   
    @IBOutlet weak var human: UIImageView!
    
    @IBAction func editprofile(_ sender: Any) {
        
        let vc = UIStoryboard(name: "Menu", bundle: nil).instantiateViewController(withIdentifier: "EditProfile") as? EditProfile
        
        self.present(vc!, animated: true, completion: nil)
        
        
    }
    //    func tranferData(data: [String]) {
//        self.array = data
//        print(self.array.count)
//        self.table.reloadData()
//    }
//    var images :[UIImage] =
    var arrayImages = ["home","icons8-info-30","notifications","icons8-private-lock-30","icons8-exit-30"]
   var array = ["Home","About us","Scorecard","Private Policy","Logout"]
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = table.dequeueReusableCell(withIdentifier: "cellpreviewTableViewCell") as! cellpreviewTableViewCell!
        cell?.label.text = array[indexPath.row]
        cell?.logo.image = UIImage(named: arrayImages[indexPath.row])
        return cell!
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      
        switch indexPath.row {

             case 0:
                self.revealViewController()?.revealToggle(animated: true)
//                revealToggleAnimated:YES
                
               // self.dismiss(animated: true, completion: nil)
//       case 0: let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeVC") as? mainpageViewController
//     self.present(vc!, animated: true, completion: nil)
         
        case 1 :

            let vc = UIStoryboard(name: "Menu", bundle: nil).instantiateViewController(withIdentifier: "about") as? about
            self.present(vc!, animated: true, completion: nil)

//            let vc = storyboard!.instantiateViewController(withIdentifier: "aboutPage") as? about
//            self.navigationController?.pushViewController(vc!, animated: true)
            
        case 2 :
    //        let vc = storyboard!.instantiateViewController(withIdentifier: "NotificationsOrg") as? notifications
      //      self.navigationController?.pushViewController(vc!, animated: false)
            let vc = UIStoryboard(name: "Menu", bundle: nil).instantiateViewController(withIdentifier: "NotificationsVC") as? notifications
            self.present(vc!, animated: true, completion: nil)
        
        case 3:  let vc = UIStoryboard(name: "Menu", bundle: nil).instantiateViewController(withIdentifier: "PolicyVC") as? policy
            
            self.present(vc!, animated: true, completion: nil)
            
        case 4:
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Login") as? Login
            let Alert = UIAlertController(title: "Logout", message: "Confirm that you want to logout", preferredStyle: .alert)
        Alert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: {(alert: UIAlertAction!) in
            self.present(vc!, animated: true, completion: nil)}))
        Alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        
        self.present(Alert, animated: true, completion: nil)
            
        default:
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeVC") as? UINavigationController
           
            self.navigationController?.pushViewController(vc!, animated: true)
           
        }
        
        
    }
    
    
    @IBOutlet weak var table: UITableView!
    
    override func viewDidLoad() {
        
//            UITableViewAutomaticDimensionntroller()
 //       x.delegate = self
    
     //   let tapGesture: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(closeSWReveal))
       // self.view.addGestureRecognizer(tapGesture)
    human.layer.borderWidth = 1.0
         human.layer.masksToBounds = false
        human.layer.borderColor = UIColor.white.cgColor
         human.layer.cornerRadius =  human.frame.size.width / 2
         human.clipsToBounds = true
      
    
    
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
//        if let navigation = self.revealViewController()?.frontViewController as? UINavigationController {
//            if let controller = navigation.viewControllers.first as? mainpageViewController {
//                controller.delegate = self
//            }
//        }
    }
    
    @objc func closeSWReveal(){
        self.revealViewController()?.revealToggle(animated: true)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any!) {
        if(segue.identifier == "goToAbout")
        {
            
            let Vcnt = segue.destination as! about
            //            Vcnt.passvalue = 1
        }
        
    }

}
//extension UIViewController
//{
//
//}

