//
//  Signup.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 28/02/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class Signup: BaseActivityViewController{

    override func viewDidLoad() {
        
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    self.navigationItem.title = "Sign Up"
    }
    //Mark: -actions
    
    

    @IBAction func login(_ sender: Any) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Login") as? Login
        
        self.present(vc!, animated: true, completion: nil)
    }
    
    @IBAction func Register(_ sender: Any) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Login") as? Login
        
        self.present(vc!, animated: true, completion: nil)
        
    }
}
