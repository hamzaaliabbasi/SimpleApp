//
//  notifications.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 23/02/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit
import GDGauge
import Cosmos

class notifications: BaseActivityViewController{
    var arr1 = ["Over-Apeeding","Harsh-Acceleration","Harsh-Breaking","Harsh-Cornering","Mileage-Crossed","No-go-Areas"]
    var arr2 = [20.0,0.0,50.0,75.0,20.0,5.0]

    
    @IBOutlet weak var gaugeview: GDGaugeView!
    
    @IBOutlet weak var cosmosView: CosmosView!
    @IBOutlet weak var table: UITableView!
    
    @IBAction func back(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)

    }
    
    // MARK: ViewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    
        self.navigationItem.title = "Driver Scorcard"
        self.navigationItem.backBarButtonItem?.title = "BACK"
        table.tableFooterView = UIView()
        
        //gaugeView
        let current = 4000
        gaugeview.baseColor = UIColor.gray
        gaugeview.startDegree = 45.0
        gaugeview.endDegree = 315.0
       gaugeview.min = 0.0
      gaugeview.max = 5000
        gaugeview.stepValue = 1000
        gaugeview.unitText =  String("Points:" + "4000")
        gaugeview.sepratorColor = UIColor.gray
       gaugeview.currentValue = CGFloat(current + 110)
        
       
       
    gaugeview.frame = CGRect(x: self.gaugeview.frame.origin.x , y: self.gaugeview.frame.origin.y, width: self.gaugeview.frame.width + 35 , height: self.gaugeview.frame.height + 30)
      gaugeview.handleColor = UIColor.gray
        
        gaugeview.setupView()
        
        //Cosmos
        cosmosView.rating = 1.3
        
        
        
    }
    

   
}
extension notifications:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr1.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ScorecardTableViewCell") as! ScorecardTableViewCell
        cell.Label1.text = arr1[indexPath.row]
        cell.label2.text = String(arr2[indexPath.row])
        cell.progressBar.progress = Float(arr2[indexPath.row]/100)
    cell.progressBar.trackTintColor = UIColor.gray.withAlphaComponent(0.4)
        if( cell.progressBar.progress >= 0 && cell.progressBar.progress < 0.5)
        {
            cell.progressBar.progressTintColor =  UIColor.green
        }
        else if(cell.progressBar.progress >= 0.5 && cell.progressBar.progress < 0.75 )
        {
            cell.progressBar.progressTintColor =  UIColor.yellow
        }
        else
        {
            cell.progressBar.progressTintColor =  UIColor.red
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 55
    }
    
}
