//
//  EditProfile.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 25/02/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class EditProfile: UIViewController {

    @IBAction func back(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func submit(_ sender: Any) {
    }
    
    

}
