//
//  about.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 23/02/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class about: UIViewController {

    @IBAction func Back(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.navigationItem.title = "About"
        self.navigationItem.backBarButtonItem?.title = "BACK"
        
    }
    

    

}
