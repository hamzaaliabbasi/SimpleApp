//
//  policyManagement.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 02/05/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class policyManagement: UIViewController {
    // MARK: GLOBALVARIABLE
    
    @IBOutlet weak var customerVuew: CardMaterialView!
    @IBOutlet weak var TechnicianView: CardMaterialView!
    //MARK: OUTLET

    //MARK: VIEWDIDLOAD
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
customerVuew.cornerRadius = 10
        TechnicianView.cornerRadius = 10
    }
    
    //MARK: ACTIONS

}
