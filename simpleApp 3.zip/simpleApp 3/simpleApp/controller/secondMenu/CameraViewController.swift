//
//  CameraViewController.swift
//  FirebaseSample
//
//  Created by Tpl Life 02 on 29/03/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit
import AVFoundation

class CameraViewController: UIViewController {
    //MARK: outlet
    
 //   @IBOutlet weak var imageview: UIImageView!
    //MARK: Buttons
    @IBOutlet weak var trunkButton: UIButton!
    @IBOutlet weak var roofButton: UIButton!
    @IBOutlet weak var EngineButton: UIButton!
    @IBOutlet weak var SuspensionButton: UIButton!
    @IBOutlet weak var DashButton: UIButton!
    @IBOutlet weak var RightButton: UIButton!
    @IBOutlet weak var LeftSideButton: UIButton!
    
    //MARK: CheckImage on Button
    @IBOutlet weak var trunk_check: UIImageView!
    @IBOutlet weak var Roof_check: UIImageView!
    @IBOutlet weak var Left_Check: UIImageView!
    @IBOutlet weak var Right_Check: UIImageView!
    @IBOutlet weak var Dash_Check: UIImageView!
    @IBOutlet weak var Suspen_Check: UIImageView!
    @IBOutlet weak var Engine_Check: UIImageView!
    
    //MARK: Label on Button
    @IBOutlet weak var TrunkLabel: UILabel!
    @IBOutlet weak var RoofLabel: UILabel!
    @IBOutlet weak var EngineLabel: UILabel!
    @IBOutlet weak var SuspenLabel: UILabel!
    @IBOutlet weak var DashLabel: UILabel!
    @IBOutlet weak var RightLabel: UILabel!
    @IBOutlet weak var LeftSideLabel: UILabel!
    //MARK: Global Variables
    lazy var submit : [Bool] = {return [false,false,false,false,false,false,false] } ()
    lazy var buttons : [UIButton] = {return [trunkButton,roofButton,LeftSideButton,RightButton,DashButton,SuspensionButton,EngineButton]}() as! [UIButton]
    lazy var Check_Image : [UIImageView] = {
        return [self.trunk_check,self.Roof_check,self.Left_Check,self.Right_Check,self.Dash_Check,self.Suspen_Check,self.Engine_Check]
    }() as! [UIImageView]
    lazy var Button_Label : [UILabel] = {return [self.TrunkLabel,self.RoofLabel,self.LeftSideLabel,self.RightLabel,self.DashLabel,self.SuspenLabel,self.EngineLabel]}() as! [UILabel]
    var captureSession = AVCaptureSession()
    var backCamera:AVCaptureDevice?
    var currentCamera: AVCaptureDevice?
    var photoOutput: AVCapturePhotoOutput?
    var cameraPreviewLayer: AVCaptureVideoPreviewLayer?
    var currentImageButton:Int?
    var trunkImage: Data?
    var image = [imageStruct]()
    //MARK: ViewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        
      self.navigationController?.setNavigationBarHidden(true, animated: false)
        let value = UIInterfaceOrientation.landscapeLeft.rawValue
        UIDevice.current.setValue(value, forKey: "orientation")
        
        trunkButton.backgroundColor = #colorLiteral(red: 1, green: 0.3426007537, blue: 0, alpha: 1)
       Button_Label[0].backgroundColor = #colorLiteral(red: 1, green: 0.3426007537, blue: 0, alpha: 1)
        setupCaptureSession()
        setupDevices()
        setupInputOutput()
        setupPreviewLayer()
        startRunningCaptureSession()
  
  
        currentImageButton = 0//setting trunkButton as the initially selected button
 
    }//viewDidLoad

    //MARK: Screen Orientation
    override var shouldAutorotate: Bool{
        return false
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask{
        return .landscapeLeft
    }
    override var preferredInterfaceOrientationForPresentation: UIInterfaceOrientation{
        return .landscapeLeft
    }

    
    //MARK: Actions
    
    @IBAction func getimage(_ sender:UIButton)
    { var count = 0
       
        for a in buttons{
            if a == sender{
                a.backgroundColor = #colorLiteral(red: 1, green: 0.3426007537, blue: 0, alpha: 1)
               currentImageButton = count
                
            }
            else{
            
                a.backgroundColor = UIColor.black
                count+=1
                }
        }
        for x in Button_Label{
            x.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        }
        
         Button_Label[currentImageButton!].backgroundColor = #colorLiteral(red: 1, green: 0.3426007537, blue: 0, alpha: 1)
        currentImageButton = buttons.firstIndex(of: sender)
         startRunningCaptureSession()
}
 

    
    @IBAction func TakePhoto(_ sender: Any) {
        let settings = AVCapturePhotoSettings()
        photoOutput?.capturePhoto(with: settings, delegate: self)
    }
    
    @IBAction func Next(_ sender: Any) {
        var ok:Bool = false
        for done in submit{
            if (done == true)
            { ok = true }
            else{
                ok = false
            }
        }
        if(ok == true)
        {
            print("Okay all images are captured,let submit it")
           
        }
        else{
            print("Dont submit")
        }
    }
    
    @IBAction func Back(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    //Functions
    func setupCaptureSession()
    {
        captureSession.sessionPreset = AVCaptureSession.Preset.photo
    }//setupCaptureSession Ends
    func setupDevices(){
        let deviceDiscoverySession = AVCaptureDevice.DiscoverySession(deviceTypes: [AVCaptureDevice.DeviceType.builtInWideAngleCamera], mediaType: AVMediaType.video, position: AVCaptureDevice.Position.unspecified)
        
        let devices = deviceDiscoverySession.devices
        
        for device in devices{
            if device.position ==  AVCaptureDevice.Position.back{
                backCamera = device
                
            }
            currentCamera = backCamera
        }
    }//setupDevices  Ends
    func setupInputOutput()
    {
        do{
            let captureDeviceInpput = try AVCaptureDeviceInput(device: currentCamera!)
            captureSession.addInput(captureDeviceInpput)
            photoOutput?.setPreparedPhotoSettingsArray([AVCapturePhotoSettings(format:[AVVideoCodecKey: AVVideoCodecType.jpeg])], completionHandler: nil)
            photoOutput = AVCapturePhotoOutput()
            captureSession.addOutput(photoOutput!)
        }
        catch{
            print(error)
        }
    }//setupInputOutput Ends
    func setupPreviewLayer(){
        cameraPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        cameraPreviewLayer?.videoGravity = AVLayerVideoGravity.resizeAspectFill
        cameraPreviewLayer?.connection?.videoOrientation = AVCaptureVideoOrientation.landscapeLeft
        cameraPreviewLayer?.frame.size = CGSize(width: self.view.frame.height, height: self.view.frame.width )
        self.view.layer.insertSublayer(cameraPreviewLayer!, at: 0)
        
        
    }//setupPreviewLayer ends
    func startRunningCaptureSession(){
        captureSession.startRunning()
    }//startRunningCaptureSession end
    
 


}//class ends

    
extension CameraViewController:AVCapturePhotoCaptureDelegate{
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        if let imageData = photo.fileDataRepresentation(){
            
            
            if(error == nil){
                if image.index(where: { $0.id == currentImageButton }) != nil{
                    print("if chla hai")
                    image[currentImageButton!].data = UIImage(data: imageData)
                }else{
                    
                    let x: imageStruct = imageStruct(id: currentImageButton, data: UIImage(data: imageData))
                    
                    image.append(x)}
                
               self.Check_Image[currentImageButton!].isHidden = false
            }
            
            captureSession.stopRunning()
            self.submit[currentImageButton!] = true
            
        }
    }
}
struct imageStruct {
    var id: Int?
    var data: UIImage?
}
extension UINavigationController {
    
    override open var shouldAutorotate: Bool {
        get {
            if let visibleVC = visibleViewController {
                return visibleVC.shouldAutorotate
            }
            return super.shouldAutorotate
        }
    }
    
    override open var preferredInterfaceOrientationForPresentation: UIInterfaceOrientation{
        get {
            if let visibleVC = visibleViewController {
                return visibleVC.preferredInterfaceOrientationForPresentation
            }
            return super.preferredInterfaceOrientationForPresentation
        }
    }
    
    override open var supportedInterfaceOrientations: UIInterfaceOrientationMask{
        get {
            if let visibleVC = visibleViewController {
                return visibleVC.supportedInterfaceOrientations
            }
            return super.supportedInterfaceOrientations
        }
    }}
