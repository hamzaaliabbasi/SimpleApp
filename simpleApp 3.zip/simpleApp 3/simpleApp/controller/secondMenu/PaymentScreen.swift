//
//  TableViewClassViewController.swift
//  Payment Screen
//
//  Created by Tpl Life 02 on 04/03/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class PaymentScreen: UIViewController,UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = table.dequeueReusableCell(withIdentifier: "cell") as! PaymentMethodCell
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 210
        
    }
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }

    
    @IBOutlet weak var table: UITableView!
    
}
