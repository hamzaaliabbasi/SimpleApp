//
//  MapViewController.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 18/04/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit
import GoogleMaps

class MapViewController: UIViewController {
    
    //MARK: Global Variable
    
    var slideViewOn: Bool?
    let status = CLLocationManager.authorizationStatus()
    let locationManager = CLLocationManager()
    var camera:GMSCameraPosition?
    var marker = [GMSMarker]()
    var circ = GMSCircle()
    var region: CLCircularRegion?
    var coordinates = CLLocationCoordinate2D()
    var PreviousMarker:Int?
    var circles = [MapCircle]()
    var CurrentMarker : Int?
    var EnterRegions = [EnterRegion]()
    var first:Bool?
    
    //MARK: Outlets
    @IBOutlet weak var constraintSlideBottom: NSLayoutConstraint!
    
    @IBOutlet weak var SlideValue: UILabel!
    
    @IBOutlet weak var SliderValueKm: UILabel!
    @IBOutlet weak var SlideView: CardMaterialView!
    @IBOutlet weak var mySlider: UISlider!
    @IBOutlet weak var MapView: GMSMapView!
    
    //MARK: ViewDidLoad
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view
        first = true
        self.MapView.delegate = self
        locationManager.delegate = self
        
        locationManager.requestAlwaysAuthorization()
        
        self.slideViewOn = false
        
        SlideView.alpha = 0.7
        
        mySlider.minimumValue = 1
        mySlider.maximumValue = 10
        mySlider.isContinuous = true
        mySlider.tintColor = UIColor.red
        mySlider.addTarget(self, action: #selector(MapViewController.sliderValueDidChange(_:)), for: .valueChanged)
        
        
        self.PreviousMarker = 0
        CurrentMarker = 0
        
        
        self.locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        
        self.locationManager.startUpdatingLocation()
        
        
        
        
    }
    //MARK: FUNCTIONS
    func createSettingsAlertController(title: String, message: String) {
        
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel, handler: nil)
        let settingsAction = UIAlertAction(title: NSLocalizedString("Settings", comment: ""), style: .default) { (UIAlertAction) in
            UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)! as URL, options: [:], completionHandler: nil)
        }
        
        alertController.addAction(cancelAction)
        alertController.addAction(settingsAction)
        self.present(alertController, animated: true, completion: nil)
        
    }// for Turning on location of phone if off currently
    
    
    func deleteCircle()
    {
        if(circles.count >= 1){
            
            circles.remove(at: CurrentMarker!)
            if let index = self.EnterRegions.firstIndex(where: { $0.id == CurrentMarker })
            {EnterRegions.remove(at: index)}
            
            print(circles.count)
            
            ShowingAllCircles()
            self.hideSliderview()
        }
        
    }// Handler for Deleting a circle
    
    
    
    func showCurrentLocation(){
        
        camera = GMSCameraPosition.camera(withLatitude: (self.locationManager.location?.coordinate.latitude)!, longitude: (self.locationManager.location?.coordinate.longitude)!, zoom: 14)
        if(first == true){
            MapView.camera = camera!
            first = false
        }
        
        MapView.settings.myLocationButton = true
        MapView.isMyLocationEnabled = true
        
        
        
    }//Shows Current Location
    
    
    func changeRadius( circle: MapCircle)
    { MapView.clear()
        //   mySlider.isHidden = false
        
        for a in circles{
            if(a.marker != circle.marker){
                //          a.region.notifyOnEntry = true
                //          a.region.notifyOnExit = true
                //          locationManager.startMonitoring(for: a.region)
                var marker1 = a.marker
                marker1.map =  MapView
                circ = GMSCircle(position: a.marker.position, radius: CLLocationDistance(100 * a.radius))
                circ.map = MapView
                circ.strokeColor =  UIColor.gray.withAlphaComponent(0.4)
                circ.strokeWidth = 3
                
                circ.fillColor = UIColor.gray.withAlphaComponent(0.4)
            }
            CheckEnterAndExitRegion()
            
        }
        
        
        var marker1 = circle.marker
        marker1.map =  MapView
        
        circ = GMSCircle(position: circle.marker.position, radius: CLLocationDistance(100 * circle.radius))
        
        circ.map = MapView
        circ.strokeColor = UIColor.red
        circ.strokeWidth = 3
        
        circ.fillColor = UIColor(red:0.63, green:0.18, blue:0.16, alpha:0.4)
        
        circles[CurrentMarker!].radius = circle.radius
        
        
        
        
    }// For Changing Of Radius Of Circle
    
    
    @objc func sliderValueDidChange(_ sender:UISlider!)
    {
        circles[CurrentMarker!].radius = mySlider.value
        changeRadius(circle:circles[CurrentMarker!])
        print("Slider value changed",sender.value)
        let value = (mySlider.value * 100)
        self.SlideValue.text = String(Int(value)) + "m "
        
        self.SliderValueKm.text = String(format: "%.2f", (value / 1000)) + " Km"
        
    }// Handler for change of Slider value
    
    
    
    func ShowingAllCircles(){
        MapView.clear()
        if(circles.count != 0){
            for a in circles{
                
                var maker1 = a.marker
                maker1.icon = GMSMarker.markerImage(with: UIColor.gray)
                maker1.map = MapView
                
                circ = GMSCircle(position: a.marker.position, radius: CLLocationDistance(100 * a.radius))
                
                circ.map = MapView
                circ.strokeColor = UIColor.gray
                circ.strokeWidth = 3
                
                circ.fillColor = UIColor.gray.withAlphaComponent(0.4)
            }}
    }// To Show All Regions Again
    
    
    func showView(){
        if(self.slideViewOn == false ){
            
            UIView.animate(withDuration: 0.8, delay: 0.0, options: UIView.AnimationOptions.curveEaseOut, animations: {
                self.constraintSlideBottom.constant = 80
                self.view.layoutIfNeeded()
            }, completion: nil)
            self.slideViewOn = true
            
        }
        else if(self.slideViewOn == true && PreviousMarker == CurrentMarker){
            self.hideSliderview()
        }
        
    }// To Show Slider View ON Tap
    
    func hideSliderview()
    {
        self.slideViewOn = false
        UIView.animate(withDuration: 0.8, delay: 0.0, options: UIView.AnimationOptions.curveEaseOut, animations: {
            self.constraintSlideBottom.constant = -160
            self.view.layoutIfNeeded()
        }, completion: nil)
        // to Hide Slider View
    }
    
    func showEnterAlert(){
        locationManager.stopUpdatingLocation()
        let Alert = UIAlertController(title: "Enter", message: "you entered in a geofence region", preferredStyle: .alert)
        Alert.addAction(UIAlertAction(title: "OK", style: .default, handler: {action in self.locationManager.startUpdatingLocation() }))
        
        
        self.present(Alert, animated: true, completion: nil)
        
    }
    func showExitAlert(){
        
        locationManager.stopUpdatingLocation()
        let Alert = UIAlertController(title: "Exit", message: "you exited from a GeoFence region", preferredStyle: .alert)
        Alert.addAction(UIAlertAction(title: "OK", style: .default, handler: {action in self.locationManager.startUpdatingLocation() }))
        
        
        self.present(Alert, animated: true, completion: nil)
    }
    
    func CheckEnterAndExitRegion()
    {   var count = 0
        for a in circles{
            let MarkerCurrentPosition = CLLocation(latitude: a.marker.position.latitude, longitude: a.marker.position.longitude)
            
            let distance = locationManager.location!.distance(from: MarkerCurrentPosition)
            if( Float(distance) <= a.radius * 100)
            {
                if let index = self.EnterRegions.index(where: { $0.id == count }){
                    print(index)
                    if(EnterRegions[index].In == false)
                    { EnterRegions[index].In = true
                        showEnterAlert()
                    }
                    
                }
                else{
                    print("Else chla")
                    EnterRegions.append(EnterRegion(id: count, In: true))
                    showEnterAlert()
                }
                
            }
            else{
                if let index = self.EnterRegions.index(where: { $0.id == count }){
                    if(EnterRegions[index].In == true)
                    { EnterRegions[index].In = false
                        showExitAlert()
                    }
                    
                }
                
            }
            
            
            
            count += 1
        }}
    
    
    //MARK: Actions
    @IBAction func deleting(_ sender: Any) {
        
        let Alert = UIAlertController(title: "Delete", message: "Confirm that you want to Delete this region", preferredStyle: .alert)
        Alert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: { action in
            //run your function here
            self.deleteCircle()
        }))
        Alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        
        self.present(Alert, animated: true, completion: nil)
        
        
    }
    
    
    
}
extension MapViewController: GMSMapViewDelegate {
    
    //MARK: Delegate Handling Of GMSMap
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        showCurrentLocation()
        CheckEnterAndExitRegion()
        
    }
    
    func mapView(_ mapView: GMSMapView, didLongPressAt coordinate: CLLocationCoordinate2D) {
        // Custom logic here
        self.slideViewOn = false
        SlideValue.text = "100 m"
        SliderValueKm.text = "0.1 Km"
        ShowingAllCircles()
        
        
        mySlider.value = mySlider.minimumValue
        let marker1 = GMSMarker()
        marker1.title = "I added this with a long tap"
        marker1.snippet = ""
        marker1.map = self.MapView
        marker1.position = coordinate
        marker1.icon = GMSMarker.markerImage(with: UIColor.red)
        
        circles.append(MapCircle(marker: marker1, radius: mySlider.value))
        
        PreviousMarker = CurrentMarker
        CurrentMarker = circles.count - 1
        self.coordinates = coordinate
        
        changeRadius(circle: circles[circles.count - 1])
        
        showView()
        
    }
    
}



extension MapViewController: CLLocationManagerDelegate{
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedAlways && status == .authorizedWhenInUse {
            
        }
        else if status == .notDetermined {
            return
        }
        else  if status == .denied || status == .restricted {
            self.createSettingsAlertController(title: "Turn on location", message: "open settings to turn on your location")
        }
        
        
    }
    
    
    
    func mapView(_ mapView: GMSMapView, didTap marker: GMSMarker) -> Bool {
        
        print(marker.position)
        
        self.ShowingAllCircles()
        
        
        
        
        
        
        if let index = circles.index(where: { $0.marker == marker }){
            circles[index].marker.icon = GMSMarker.markerImage(with: UIColor.red)
            circ = GMSCircle(position: circles[index].marker.position, radius: CLLocationDistance(100 * circles[index].radius))
            
            circ.map = MapView
            circ.strokeColor = UIColor.red
            circ.strokeWidth = 3
            
            circ.fillColor = UIColor.red.withAlphaComponent(0.4)
            print(index)
            
            let value = circles[index].radius * 100
            self.SlideValue.text = String(format: "%.0f",value) + "m "
            self.SliderValueKm.text = String(format: "%.2f", (value / 1000)) + " Km"
            PreviousMarker = CurrentMarker
            CurrentMarker = index
            mySlider.value = circles[index].radius
            //         locationManager.startMonitoring(for: circles[index].region)
            
        }
        
        showView()
        return true
    }
    
    
    
    
    func mapView(_ mapView: GMSMapView, didTapAt coordinate: CLLocationCoordinate2D) {
        
        ShowingAllCircles()
        
        hideSliderview()
        
    }
    
    
    
    
    
    
}
struct MapCircle {
    var marker:GMSMarker
    var radius:Float
    
}
struct EnterRegion {
    var id: Int
    var In:Bool
}

