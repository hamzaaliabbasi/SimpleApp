//
//  CollectionViewController.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 15/05/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class CollectionViewController: UIViewController {
    //MARK: GlobalVariable
    var services = ["Car Inspection","Car Repair","Car Wash","Oil Change","Car Inspection","Car Repair","Car Wash","Oil Change"]
    var month = ["January","February","March","April","May","June","July","August","September","October","November","December"]
    var days = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31]
    @IBOutlet weak var collection: UICollectionView!
    
    @IBOutlet weak var CollectionDay: UICollectionView!
    @IBOutlet weak var CollectionMonth: UICollectionView!
    //MARK: ViewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

}
extension CollectionViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if(collectionView == collection)
        {return services.count}
        else if(collectionView == CollectionDay)
        {return days.count}
        else {
            return month.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if(collectionView == collection){
        let cell =
            collectionView.dequeueReusableCell(withReuseIdentifier:"CollectionViewCell", for: indexPath) as! CollectionViewCell
        cell.Cell_image.image = UIImage(named: services[indexPath.item])
        cell.Cell_Label.text =  services[indexPath.item]
        cell.CardView.cornerRadius = 10
            return cell}
        else if(collectionView == CollectionDay)
        {   let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CalenderCollectionViewCell", for: indexPath) as! CalenderCollectionViewCell
             cell.CardLabel.text = String(days[indexPath.item])
              cell.MainView.cornerRadius = 5
            return cell
        }
        else
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CalendarMonthCollectionViewCell", for: indexPath) as! CalendarMonthCollectionViewCell
             cell.CardLAbel.text = String(month[indexPath.item])
            cell.Mainview.cornerRadius = 5
        return cell
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if(collectionView == collection){
        return CGSize(width: collectionView.frame.width/2 - 15, height: 180.0)    }
    else if(collectionView == CollectionDay)
        {
          return CGSize(width: collectionView.frame.width/7 - 15, height: collectionView.frame.height/4)
        }
       else{
       return CGSize(width: collectionView.frame.width - 10, height: 25)
        }
        
    }
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
//        return 10
//    }
//
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
//        return 10
//    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 10, left: 5, bottom: 10, right: 5)
    }
    
}
