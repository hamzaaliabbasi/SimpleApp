//
//  PaymentScreenVC.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 06/03/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class PaymentScreenVC:UIViewController,UITableViewDelegate,UITableViewDataSource{
    var height: CGFloat?
    var selected: Int?
    var value:[Bool] = [false,false,false,false]
    //Marks: - Outlets
    
    @IBOutlet weak var table: UITableView!
    
    //Mark: - ViewDidLoad
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        table.tableFooterView = UIView()
        
        // Do any additional setup after loading the view.
        height = 55
        selected = 0
     
        
        table.reloadData()
        table.layoutIfNeeded()
        table.heightAnchor.constraint(equalToConstant: table.contentSize.height).isActive = true
        
    }
    
    
    
    //Mark : - Delegate
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if(indexPath.row == 0)
        {let cell = table.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
            return cell
        }
        else if(indexPath.row == 1)
        {let cell = table.dequeueReusableCell(withIdentifier: "cell1") as! SimsimCell
            return cell}
        else if(indexPath.row == 2)
        {let cell = table.dequeueReusableCell(withIdentifier: "cell2") as! EasyCell
            return cell}
        else if(indexPath.row == 3)
        {let cell = table.dequeueReusableCell(withIdentifier: "cell3") as! JazzCashCell
            return cell}
        return tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if(indexPath.row ==  0 )
        {
            height = 130.0
            selected = 0
            for a in 0...3{
                if(a != indexPath.row)
                { value[a] = false}
                else
                { value[indexPath.row] = !value[indexPath.row]}
                
            }//for
            
        }
            
            
        else if (indexPath.row ==  1 )
        {
            height = 140
            selected = 1
            
            for a in 0...3{
                if(a != indexPath.row)
                { value[a] = false}
                else
                { value[indexPath.row] = !value[indexPath.row]}
                
            }//for
        }
            
        else if (indexPath.row ==  2 )
        {
            height = 100
            selected = 2
            for a in 0...3{
                if(a != indexPath.row)
                { value[a] = false}
                else
                { value[indexPath.row] = !value[indexPath.row]}
                
            }//for
            
        }
            
        else if (indexPath.row ==  3 )
        {
            height = 210
            
            selected = 3
            for a in 0...3{
                if(a != indexPath.row)
                { value[a] = false}
                else
                { value[indexPath.row] = !value[indexPath.row]}
                
            }//fore
        }
        
        tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.row == selected && value[indexPath.row] == true)
        {
            return height!
        }
        else{
            return 55}
    }
    
    
   
    
    
    
}
