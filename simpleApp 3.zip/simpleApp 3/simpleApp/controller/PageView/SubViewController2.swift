//
//  SubViewController2.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 18/03/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class SubViewController2: UIViewController {

    @IBOutlet weak var scroll: UIPageControl!
    
    @IBOutlet weak var image: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    
    }
    

}
