//
//  CardViewClass.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 28/02/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class CardViewClass: UITableViewCell {

    @IBOutlet weak var myView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    policyimage.layer.cornerRadius = 20.0
        policyimage.layer.maskedCorners = [.layerMaxXMinYCorner,.layerMinXMinYCorner]
        policyimage.clipsToBounds = true
        myView!.layer.cornerRadius = 20.0
        myView!.layer.shadowColor = UIColor.gray.cgColor
        myView!.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        myView!.layer.shadowRadius = 12.0
        myView!.layer.shadowOpacity = 0.7
        
        
        
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    //Mark: -outlets
 
    
    @IBOutlet weak var no: UILabel!

    @IBOutlet weak var policy: UILabel!
    
   
    @IBOutlet weak var policyimage: UIImageView!
    
}

