//
//  SimsimCell.swift
//  Payment Screen
//
//  Created by Tpl Life 02 on 06/03/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class SimsimCell: UITableViewCell {

    @IBOutlet weak var NumText: UITextField!
    
   
    @IBOutlet weak var myView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
     //   myView!.layer.cornerRadius = 20.0
        myView!.layer.shadowColor = UIColor.gray.cgColor
        myView!.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        myView!.layer.shadowRadius = 12.0
        myView!.layer.shadowOpacity = 0.7
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state\
        
        
        
    }
    
    @IBAction func action(_ sender: UIButton) {
        
        if sender.isSelected {
            sender.isSelected = false
        }else {
            sender.isSelected = true
        }
        
    }
    

}
