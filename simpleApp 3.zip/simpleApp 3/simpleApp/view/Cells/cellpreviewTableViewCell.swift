//
//  cellpreviewTableViewCell.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 21/02/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class cellpreviewTableViewCell: UITableViewCell {


    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBOutlet weak var logo: UIImageView!
    @IBOutlet weak var label: UILabel!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
