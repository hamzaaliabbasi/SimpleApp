//
//  ScorecardTableViewCell.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 21/05/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class ScorecardTableViewCell: UITableViewCell {
    //MARK: - Outlets
    
    @IBOutlet weak var CardView: CardMaterialView!
    @IBOutlet weak var Label1: UILabel!
    
    @IBOutlet weak var label2: UILabel!
    
    @IBOutlet weak var progressBar: UIProgressView!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Initialization code
    //CardView.cornerRadius = 10
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
