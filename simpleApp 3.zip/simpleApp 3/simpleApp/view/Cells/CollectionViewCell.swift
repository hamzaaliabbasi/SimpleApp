//
//  CollectionViewCell.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 15/05/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var Cell_image: UIImageView!
    
    @IBOutlet weak var CardView: CardMaterialView!
    @IBOutlet weak var Cell_Label: UILabel!
}
