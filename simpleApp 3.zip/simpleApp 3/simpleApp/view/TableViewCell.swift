//
//  TableViewCell.swift
//  Payment Screen
//
//  Created by Tpl Life 02 on 04/03/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit



class TableViewCell: UITableViewCell {


    
    @IBOutlet weak var myview: UIView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
       // myview!.layer.cornerRadius = 15.0
        myview!.layer.shadowColor = UIColor.gray.cgColor
        myview!.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        myview!.layer.shadowRadius = 12.0
        myview!.layer.shadowOpacity = 0.7
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func checkButton(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
        }else {
            sender.isSelected = true
        }
    }
    

    
}
