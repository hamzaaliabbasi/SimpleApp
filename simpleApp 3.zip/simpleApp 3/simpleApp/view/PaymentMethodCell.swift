//
//  TableViewCell.swift
//  Payment Screen
//
//  Created by Tpl Life 02 on 04/03/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit



class PaymentMethodCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func checkButton(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
        }else {
            sender.isSelected = true
        }
    }
    

    
}
