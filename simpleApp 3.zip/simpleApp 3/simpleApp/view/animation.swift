//
//  animation.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 01/03/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import Foundation
