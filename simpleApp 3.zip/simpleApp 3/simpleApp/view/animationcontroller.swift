//
//  animationcontroller.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 01/03/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import Foundation
import  UIKit
class animationControllrt: NSObject,UIViewControllerAnimatedTransitioning
{
    private let aimationDuration:Double
    private let animationtype:animationType
    enum animationType{
        case present
        case dismiss
        
    }
    //MARK: - init
    init(animationDuration:Double,animationtype:animationType) {
        
        self.aimationDuration = animationDuration
        self.animationtype = animationtype
    }
    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        return TimeInterval(exactly: self.aimationDuration) ?? 0
    }
    
    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        guard let toViewController = transitionContext.viewController(forKey: .to) ,
            let fromViewController = transitionContext.viewController(forKey: .from)  else
        { transitionContext.completeTransition(false)
                return
        }
        switch animationtype {
        case .present:
            transitionContext.containerView.addSubview(toViewController.view)
           presentAnimation(with: transitionContext, viewToAnimate: toViewController.view)
        case.dismiss:
            print("implement this")
        }
    }
    func presentAnimation( with transitionContext:UIViewControllerContextTransitioning,viewToAnimate: UIView)
    { let duration = transitionDuration(using: transitionContext)
        viewToAnimate.clipsToBounds = true
        viewToAnimate.transform = CGAffineTransform(scaleX: 0, y: 0)
        UIView.animate(withDuration: duration, delay: 0, usingSpringWithDamping: 0.80, initialSpringVelocity: 0.1, options: .curveEaseInOut, animations: {
            viewToAnimate.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        }) { _ in
            transitionContext.completeTransition(true)
        }
    
    
}
}
